﻿
namespace arcsoft {
    public class ASVL_COLOR_FORMAT {
        public const int ASVL_PAF_I420 = 0x601;
        public const int ASVL_PAF_NV12 = 0x801;
        public const int ASVL_PAF_NV21 = 0x802;
        public const int ASVL_PAF_YUYV = 0x501;
    }
}
